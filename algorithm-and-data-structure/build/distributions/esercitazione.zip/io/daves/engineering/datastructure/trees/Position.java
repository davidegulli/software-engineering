package io.daves.engineering.datastructure.trees;

public interface Position<E> {

    E getElement();
}
