# Lesson 29 - Attraversamenti di un grafo

### Instructions to run the exercises application

__Requirements:__ The application require the jdk 1.8 to be executed 

In order to execute the main classes of the solved exercises, it needs to run the following commands:


Depth First Searcher exercise:
```bash
$ java io.daves.engineering.algorithm.depth_first_search.DepthFirstSearcher
```

Breadth First Searcher exercise:
```bash
$ java io.daves.engineering.algorithm.breadth_first_search.BreadthFirstSearcher
```